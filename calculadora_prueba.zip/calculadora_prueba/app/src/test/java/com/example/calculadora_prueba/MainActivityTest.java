package com.example.calculadora_prueba;

import static org.junit.Assert.assertEquals;

import junit.framework.TestCase;

import org.junit.Test;

public class MainActivityTest{



    @Test
    public void suma() {
        double resultado = MainActivity.suma(5,5);
        assertEquals(8.0, resultado, 0.01);
        System.out.println("El resultado de la suma es: " + resultado);
    }

    @Test
    public void resta() {
        double resultado = MainActivity.resta(5,3);
        assertEquals(2.0, resultado, 0.01);
        System.out.println("El resultado de la resta es: " + resultado);

    }
    @Test
    public void multiplicacion() {
        double resultado = MainActivity.multiplicacion(5,3);
        assertEquals(15, resultado, 0.01);
        System.out.println("El resultado de la multiplicacion es: " + resultado);

    }


    @Test
    public void division() {
        // Caso de división normal
        double resultadoEsperado = 1.0;
        double resultadoReal = MainActivity.division(5, 6);//5,5
        assertEquals(resultadoEsperado, resultadoReal, 0.0001); // Ajusta la precisión según sea necesario


    }

    /*@Test
    public void testFibonacci() {
        assertEquals("0.0\n1.1\n2.1\n3.2\n4.3\n", MainActivity.fibonacci(5));
        assertEquals("0.0\n1.1\n2.1\n3.2\n4.3\n5.5\n", MainActivity.fibonacci(6));
        //se puede agregar mas pruebas 0
    }*/


    @Test
    public void testCalculateRecursiveFactorial() {
        MainActivity mainActivity = new MainActivity();
        // caso base 0
        assertEquals("Factorial de 0 incorrecto", 1, mainActivity.calculateRecursiveFactorial(5).intValue());

        //caso base 1
        assertEquals("Factorial de 1 incorrecto", 1, mainActivity.calculateRecursiveFactorial(1).intValue());

        //número mayor
        assertEquals("Factorial de 5 incorrecto", 120, mainActivity.calculateRecursiveFactorial(5).intValue());

        // Agrega más casos de prueba según sea necesario
    }
}


